@echo off
echo ================================================
echo  SMS App - WebView2 Runtime Installer
echo ================================================
echo.
echo Checking if Microsoft WebView2 Runtime is installed...

reg query "HKLM\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" >nul 2>&1
if %ERRORLEVEL% == 0 (
    echo WebView2 Runtime is already installed!
    echo.
    echo Launching SMS App...
    start "" "%~dp0sms_app.exe"
    exit /b 0
)

reg query "HKLM\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" >nul 2>&1
if %ERRORLEVEL% == 0 (
    echo WebView2 Runtime is already installed!
    echo.
    echo Launching SMS App...
    start "" "%~dp0sms_app.exe"
    exit /b 0
)

echo WebView2 Runtime is NOT installed. Downloading installer...
echo This is a one-time setup required by Microsoft (it's free).
echo.

curl -L -o "%TEMP%\MicrosoftEdgeWebview2Setup.exe" "https://go.microsoft.com/fwlink/p/?LinkId=2124703"

if %ERRORLEVEL% == 0 (
    echo Download complete. Installing WebView2 Runtime...
    "%TEMP%\MicrosoftEdgeWebview2Setup.exe" /install
    echo.
    echo Installation complete! Launching SMS App...
    start "" "%~dp0sms_app.exe"
) else (
    echo Download failed. Please install WebView2 manually from:
    echo https://developer.microsoft.com/en-us/microsoft-edge/webview2/
    pause
)
